import Empleados.*;

import java.util.ArrayList;

public class main_empleados {
    public static void main(String[] args) {
        //Genero los empleados
        Empleado_Asalariado empleadoAsalariado = new Empleado_Asalariado("Marcos","Rojo", "+54 9 1156879865", "21-21212121-9",
                10, 15000);

        Empleado_PorComision empleadoPorComision = new Empleado_PorComision("Frank", "Fabra","1156958746", "42-654854321-6", 10, 50,
                50000, 50);

        Empleado_PorComision_SalarioBase empleadoPorComisionSalarioBase = new Empleado_PorComision_SalarioBase("Marcos", "Gonzalez", "+54 5 9283548496", "84-51234151-8", 5, 512, 100000, 75, 20000);

        Empleado_PorHora empleadoPorHora = new Empleado_PorHora("Edison", "Cavani", "+5185151541", "51-676512341-5", 5,
                875.5, 40);

        Empleado_Pasante pasante = new Empleado_Pasante("Valentin", "Barco", "115654649", "51-765231651-8", 10);

        //Cargo los empleados a un ArrayList
        ArrayList<Empleado> empleados = new ArrayList<>();
        empleados.add(empleadoAsalariado);
        empleados.add(empleadoPorComision);
        empleados.add(empleadoPorComisionSalarioBase);
        empleados.add(empleadoPorHora);
        empleados.add(pasante);
        System.out.println("\t\tSUELDOS POR EMPLEADOS");
        for (Empleado empleado : empleados) {
            double sueldo = empleado.calcular_sueldo();
            System.out.println("Sueldo del empleado " + empleado.getApellido() + ", " + empleado.getNombre() + " es :  $" + sueldo);
        }
    }
}
