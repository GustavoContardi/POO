import BilleteraVirtual.CuentaNormal;
import BilleteraVirtual.Usuario;

public class BilleterasVirtuales {
    public static void main(String[] si){
        CuentaNormal cuenta1 = new CuentaNormal();
        Usuario usuario = new Usuario("Gustavo", cuenta1);

        usuario.cargarSaldo(100000);
        usuario.ver_saldo();
        usuario.invertirDinero(100000, 15);
        usuario.ver_saldo();
        usuario.realizar_compra(150000);
        usuario.ver_montoTotal();
        usuario.ver_giroDescubierto();

        usuario.pedir_cuenta_credito();
        usuario.realizar_gasto_credito(250000);
        usuario.ver_deuda_credito();
    }
}
