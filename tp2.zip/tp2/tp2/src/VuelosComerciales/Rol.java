package VuelosComerciales;

public abstract class Rol {

    private int idRol;
    private static int id = 0;

    public Rol() {
        this.idRol = id;
        id++;
    }

    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public void nuevoRecibo(ReciboSueldo rc) {
    }
    public String getCargo() {
        return "SIN CARGO";
    }
    public void setCargo(String cargo) {
    }

    public String getNumeroPasajero() {
        return "SIN NUMERO DE PASAJERO. CREE UNO.";
    }

    public void setNumeroPasajero(String numeroPasajero) {
    }

}
