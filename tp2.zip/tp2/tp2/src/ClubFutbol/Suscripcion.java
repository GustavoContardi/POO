package ClubFutbol;

import java.util.ArrayList;

public class Suscripcion {
    private String suscripcion;

    private static ArrayList<String> actividades = new ArrayList<>();

    public Suscripcion(String suscripcion) {
        this.suscripcion = suscripcion;
        if(actividades.isEmpty()){
            actividades.add("Pileta");
            actividades.add("Tenis");
            actividades.add("Padel");
            actividades.add("Quincho");
            actividades.add("Metegol");
            actividades.add("Voley");
            actividades.add("Patin");
            actividades.add("Basquet");
            actividades.add("Gimnasio");
            actividades.add("Lionel Andres Messi");
        }

    }

    public String getSuscripcion() {
        return suscripcion;
    }

    public void setSuscripcion(String suscripcion) {
        this.suscripcion = suscripcion;
    }

    public ArrayList<String> getActividades() {
        return actividades;
    }

    public void setActividades(String actividad) {
        this.actividades.add(actividad);
    }

    public void mostrar_actividades_sub(String sub){
        int acts = 0;

        if(sub.equalsIgnoreCase("basico")) acts = 3;
        if(sub.equalsIgnoreCase("Intermedio")) acts = 6;
        if(sub.equalsIgnoreCase("destacada")) acts = actividades.size();

        System.out.printf("\nACTIVIDADES DISPONIBLES PARA SOCIO NIVEL -- %s --\n", sub.toUpperCase());
        for(int i=0; i<acts; i++){
            System.out.println("- " + actividades.get(i));
        }
    }
}
