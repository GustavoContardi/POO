package ClubFutbol;

import java.util.ArrayList;

public class Personal {
    private String nombre;
    private ArrayList<Socio> socios = new ArrayList<>();
    private ArrayList<Credencial> credenciales = new ArrayList<>();
    private Credencial credencial;
    private Suscripcion suscripcion = new Suscripcion("");

    public Personal(String nombre) {
        this.nombre = nombre;
    }

    public void nuevoSocio(Socio socio, String sub){
        credencial = new Credencial(sub, socio);
        socio.setCredencial(credencial);
        credenciales.add(credencial);
        socios.add(socio);
    }

    public void sociosInscriptos(){
        System.out.println("\n\t\tSOCIOS INSCRIPTOS\n");
        //System.out.println("\tNombre \tApellido  \tID  \tSuscripcion  \tE-Mail");
        for(int i=0; i<socios.size(); i++){
            System.out.printf("%s  %s %d %s  %s  \n", socios.get(i).getNombre(), socios.get(i).getApellido(), socios.get(i).getId(), socios.get(i).getCredencial().getSuscripcion().getSuscripcion(), socios.get(i).getEmail());
        }
    }

    public void actividadesPorSub(String sub){
        credencial.getSuscripcion().mostrar_actividades_sub(sub);
    }

    public void sociosPorSuscripcion(String sub){
        System.out.printf("\n\t\tSOCIOS POR SUSCRIPCION -- %s --\n\n",sub.toUpperCase());
       // System.out.println("\tNombre \tApellido \tID \tE-Mail");
        for(int i=0; i<socios.size(); i++){
            if(socios.get(i).getCredencial().getSuscripcion().getSuscripcion().equalsIgnoreCase(sub)) {
                System.out.printf("%s  %s   %d  %s \n", socios.get(i).getNombre(), socios.get(i).getApellido(), socios.get(i).getId(), socios.get(i).getEmail());
            }
        }
    }
}
