package ClubFutbol;

public class Credencial {
    private int numeroCredencial;
    private Socio socio;
    private Suscripcion suscripcion;

    public Credencial(String sub, Socio socio) {
        this.numeroCredencial = (int) (Math.random() * 1000) + 1;
        this.socio = socio;
        this.suscripcion = new Suscripcion(sub);
    }

    public Suscripcion getSuscripcion() {
        return suscripcion;
    }

    public int getNumeroCredencial() {
        return numeroCredencial;
    }

    public Socio getSocio() {
        return socio;
    }

}
