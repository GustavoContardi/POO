package AcademiaDanza;

public class Asistencia {
    private Credencial credencial;
    private Diagramacion diagramacion;

}
