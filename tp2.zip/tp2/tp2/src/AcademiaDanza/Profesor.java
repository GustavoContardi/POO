package AcademiaDanza;

public class Profesor {
    private String nombre;
    private int sueldo;
    private Disciplina disciplina;

    public Profesor(String nombre, Disciplina disciplina) {
        this.nombre = nombre;
        this.disciplina = disciplina;
        sueldo = 0;
    }

    public void asistio(){
        sueldo += 10;
    }

    public String getNombre() {
        return nombre;
    }
}
