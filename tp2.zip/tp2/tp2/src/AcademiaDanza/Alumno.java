package AcademiaDanza;

public class Alumno {
    private String nombre;
    private String Email;
    private Credencial credencial;
    private int diasAsistidos = 0;

    public Alumno(String nombre, String email) {
        this.nombre = nombre;
        Email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return Email;
    }

    public Credencial getCredencial() {
        return credencial;
    }

    public int getDiasAsistidos() {
        return diasAsistidos;
    }

    public void setDiasAsistidos(int diasAsistidos) {
        this.diasAsistidos = diasAsistidos;
    }

    public void setCredencial(Credencial credencial) {
        this.credencial = credencial;
    }
}
