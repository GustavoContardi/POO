package AcademiaDanza;

import java.util.ArrayList;

public class Secretaria {
    private ArrayList<Alumno> listadoAlumnos = new ArrayList<>();
    private Alumno alumno;
    private ArrayList<Diagramacion> diagramaciones = new ArrayList<>();
    private Diagramacion diagramacion;


    public void altaAlumno(Alumno alumno1, Disciplina disciplina){
        listadoAlumnos.add(alumno1);
        for(int i=0; i<diagramaciones.size(); i++){
            diagramacion = diagramaciones.get(i);
            if(diagramacion.getDisciplina().equals(disciplina)){
                Credencial nueva_credencial = new Credencial(alumno1, diagramacion);
                alumno1.setCredencial(nueva_credencial);
            }
        }
    }

    public void tomar_asistencia(Credencial credencial){
        if(credencial != null){
            alumno = credencial.getAlumno();
            if(credencial.getDiasAsistibles() >= alumno.getDiasAsistidos()){
                alumno.setDiasAsistidos(alumno.getDiasAsistidos() + 1);
                credencial.getDiagramacion().getProfesor().asistio();
            }
            else{
                System.out.println("Ya asistio a todas sus clases en el mes.");
            }
        }
    }

    public void cargarDiagramaciones(Diagramacion diagramacion){
        diagramaciones.add(diagramacion);
    }

}
