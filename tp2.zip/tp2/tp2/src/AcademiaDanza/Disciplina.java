package AcademiaDanza;

public class Disciplina {
    private String disciplina;
    private String Nivel;

    public Disciplina(String disciplina, String nivel) {
        this.disciplina = disciplina;
        this.Nivel = nivel;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public String getNivel() {
        return Nivel;
    }
}
