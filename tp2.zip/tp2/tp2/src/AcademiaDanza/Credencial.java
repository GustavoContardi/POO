package AcademiaDanza;

public class Credencial {
    private int id_credencial;
    private Alumno alumno;
    private Diagramacion diagramacion;
    private static int id_general=1;
    private int diasAsistibles;

    public Credencial(Alumno alumno, Diagramacion diagramacion) {
        this.id_credencial = id_general++;
        this.alumno = alumno;
        this.diagramacion = diagramacion;
        diasAsistibles = (diagramacion.getDias().size() * 4) - 1;
    }

    public int getId_credencial() {
        return id_credencial;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public Diagramacion getDiagramacion() {
        return diagramacion;
    }

    public int getDiasAsistibles() {
        return diasAsistibles;
    }

}
