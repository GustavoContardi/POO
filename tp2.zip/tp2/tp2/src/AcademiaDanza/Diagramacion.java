package AcademiaDanza;

import java.time.LocalDate;
import java.util.ArrayList;

public class Diagramacion {
    private String horario;
    private Disciplina disciplina;
    private ArrayList<String> dias;
    private Profesor profesor;

    public Diagramacion(String horario, Disciplina disciplina, ArrayList<String> dias, Profesor profe) {
        this.horario = horario;
        this.disciplina = disciplina;
        this.dias = dias;
        this.profesor = profe;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public ArrayList<String> getDias() {
        return dias;
    }

    public Profesor getProfesor() {
        return profesor;
    }
    public void verDiasClases(){
        System.out.printf("\tDIAS Y HORARIO - %s - 2023\n\n", disciplina.getDisciplina());
        for(int i=0; i< dias.size(); i++){
            System.out.printf("- %s: %s\n", dias.get(i).toUpperCase(), horario);
        }
        System.out.println("\nLa clase la da el profesor: " + profesor.getNombre());
    }
}
