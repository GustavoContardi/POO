package BilleteraVirtual;

public class CuentaCredito {
    private int id_cuentaCredito;
    private static int id_estatico = 1;
    private double limiteCompra;
    private double limiteGasto;
    private double gastos;

    public CuentaCredito() {
        limiteCompra = 1500000.0;
        limiteGasto = limiteCompra;
        gastos = 0.0;
    }

    public void realizar_gasto(int gasto){
        if(gasto <= limiteGasto){
            limiteGasto -= gasto;
            gastos += gasto*1.05;
            System.out.println("Compra realizada!");
        }
        else{
            System.out.println("Su gasto supero el limite de credito asignado!");
        }
    }
    public void pagar_deuda(int monto){
        limiteGasto += monto;
        gastos -= monto;
        limiteCompra += monto * 0.03;
    }
    public void mostrar_deuda(){
        System.out.println("Usted debe " + gastos);
    }


}
