package BilleteraVirtual;

public class Usuario {
    private int id_usuario;
    private static int id_estatico = 1;
    private String nombre;
    private CuentaCredito cuentaCredito;
    private CuentaNormal cuentaNormal;

    public Usuario(String nombre, CuentaNormal cuenta) {
        this.nombre = nombre;
        id_usuario = id_estatico++;
        cuentaNormal = cuenta;
    }

    public void pedir_cuenta_credito(){
        if(cuentaCredito == null){
            cuentaCredito = new CuentaCredito();
            System.out.println("¡Cuenta creada con exito!");
        }
        else{
            System.out.println("¡Cuenta ya existente!");
        }
    }

 // -------------------------------------- NORMAL ---------------------------------------------------- //

    public void ver_saldo(){
        System.out.println("Saldo actual: " + cuentaNormal.getSaldo());
    }

    public void ver_dineroInvertido (){
        System.out.println("Dinero invertido actual: " + cuentaNormal.getDineroInvertido());
    }

    public void ver_giroDescubierto(){
        System.out.println("El giro descubierto disponible es de: " + cuentaNormal.getGiroDescubierto());
    }

    public void ver_montoTotal(){
        System.out.println("El monto total a gastar es: " + cuentaNormal.getMontoTotal());
    }

    public void cargarSaldo(int saldo){
        cuentaNormal.cargar_saldo(saldo);
    }

    public void invertirDinero(int monto, int dias){
        cuentaNormal.invertirDinero(monto, dias);
    }

    public void realizar_compra(int monto){
        cuentaNormal.gastar_dinero(monto);
    }

    public void ver_inversion(){
        cuentaNormal.ver_inversion();
    }

    // ----------------------------- CREDITO ------------------------------------- //

    public void realizar_gasto_credito(int gasto){
        if(cuentaCredito == null) System.out.println("Usted no posee una cuenta credito");
        else cuentaCredito.realizar_gasto(gasto);
    }

    public void pagar_deuda_credito(int monto){
        if(cuentaCredito == null) System.out.println("Usted no posee una cuenta credito");
        else cuentaCredito.pagar_deuda(monto);
    }

    public void ver_deuda_credito(){
        if(cuentaCredito == null) System.out.println("Usted no posee una cuenta credito");
        else cuentaCredito.mostrar_deuda();
    }
}
