package BilleteraVirtual;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class CuentaNormal {
    private int id_cuentaNormal;
    private static int id_estatico = 1;
    private double saldo;
    private double giroDescubierto;
    private double dineroInvertido;
    private double montoTotal;
    private LocalDate fecha_devolucion_inversion;
    private Usuario usuario;

    public CuentaNormal() {
        this.id_cuentaNormal = id_estatico++;
        saldo = 0.0;
        giroDescubierto = 150000.0;
        dineroInvertido = 0.0;
        montoTotal = saldo + giroDescubierto;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getGiroDescubierto() {
        return giroDescubierto;
    }

    public double getDineroInvertido() {
        return dineroInvertido;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void cargar_saldo(int saldo){
        this.saldo += saldo;
        if(giroDescubierto < 150000){
            double aux = 150000 - giroDescubierto;
            this.saldo -= aux;
            giroDescubierto += aux;

        }
    }
    public void ver_inversion(){
        if(dineroInvertido != 0.0) {
            LocalDate fecha = LocalDate.now();
            if (fecha.equals(fecha_devolucion_inversion)) {
                saldo += dineroInvertido * 1.40;
            }
            System.out.printf("Usted tiene %.2f$ invertidos! ", dineroInvertido);
        }
        else{
            System.out.println("Usted no tiene dinero invertido\n");
        }
    }

    public void invertirDinero(int dinero, int dias_a_invertir){
        LocalDate fecha = LocalDate.now();
        if(dineroInvertido == 0.0){
            if(dinero <= saldo) {
                fecha_devolucion_inversion = fecha.plusDays(dias_a_invertir);
                dineroInvertido += dinero;
                saldo -= dinero;
            }
            else System.out.println("¡Usted no tiene ese dinero para invertir! Cargue saldo desde la APP...");
        }
        else{
            System.out.println("Usted ya tiene dinero invertido\n");
        }
    }

    public void gastar_dinero(int monto){
        if(monto > montoTotal){
            System.out.println("Dinero insuficiente");
        }
        else{
            double aux;
            if(saldo < monto){
                aux = monto - saldo;
                if(saldo + dineroInvertido >= monto){
                    retirarInversion(aux);
                    saldo -= monto;
                }
                else{
                    retirarInversion(dineroInvertido);
                    aux = monto - saldo;
                    saldo = 0.0;
                    giroDescubierto -= aux;
                }

            }
            else if(saldo == monto){
                saldo = 0.0;
            }
            else{
                saldo -= monto;
            }
            montoTotal -= monto;
        }
    }

    public void retirarInversion(double monto){
        if(monto <= dineroInvertido) {
            LocalDate fecha_actual = LocalDate.now();
            long dias = fecha_devolucion_inversion.until(fecha_actual, ChronoUnit.DAYS);
            if(dias >= 30){
                monto = (monto * 1.05);
            }
            saldo += monto;
            dineroInvertido -= monto;
        }
        else System.out.println("¡Error! Ingrese un monto igual o menor a su inversion.");

    }

}
