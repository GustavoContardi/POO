import EstacionServicio.*;

public class main_EstacionServicio {
    public static void main(String[] argumentos){

        Cliente cliente1 = new Cliente("Messi", "ppj298");
        Cliente cliente2 = new Cliente("Ronaldo ", "ghj953");
        Cliente cliente3 = new Cliente("Neymar", "loi153");
        Cliente cliente4 = new Cliente("Cavani", "nnn992");
        Cliente cliente5 = new Cliente("Suarez", "mnm723");

        Combustible gasoil = new Combustible("gasoil", 50);
        Surtidor expendedorGasoil = new Surtidor(gasoil, 300);
        Combustible nafta = new Combustible("nafta", 250);
        Surtidor expendedorNafta = new Surtidor(nafta, 300);
        Combustible kerosene = new Combustible("kerosene", 250);
        Surtidor expendedorKerosene = new Surtidor(kerosene, 300);

        Empleado playero1 = new Empleado("Gustavo", "Contardi");
        Empleado playero2 = new Empleado("Federico", "Contardi");
        Informe.agregarPlayeros(playero1);
        Informe.agregarPlayeros(playero2);

        playero1.atenderCliente(cliente1, 100, expendedorNafta, true);
        playero1.atenderCliente(cliente2, 100, expendedorNafta, false);
        playero1.atenderCliente(cliente3, 150, expendedorNafta, false);
        playero1.atenderCliente(cliente4, 120, expendedorNafta, true);
        playero1.atenderCliente(cliente5, 140, expendedorNafta, true);

        System.out.println("\n\n\t\t YPF - RACING CLUB -");

        Informe.expendedoresPorLitrosExpendidos();
        System.out.println("\n-------------------------------");
        Informe.empleadosPorMontoTotalDeVentas();
        System.out.println("\n-------------------------------");
        Informe.clienteSegunMontoTotal();
        System.out.println("\n-------------------------------");
        Informe.realizarDescuento(playero1,300, expendedorGasoil);

    }
}
