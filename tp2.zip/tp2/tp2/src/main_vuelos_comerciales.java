import VuelosComerciales.*;

public class main_vuelos_comerciales {
    public static void main(String[] argumentos){

        /* -- Prueba del ejercicio Vuelos Comerciales -- */

        Persona messi = new Persona("Messi", "2323-998877", "Unlu");
        Persona mbappe = new Persona("Mbappe", "2323-887799", "Unlu");
        Persona neymar = new Persona("Neymar", "2323-778899", "Unlu");

        Rol tripulanteMessi = new Tripulante("Copiloto");
        Rol tripulanteMbappe = new Tripulante("Piloto");

        messi.agregarRol(tripulanteMessi);
        mbappe.agregarRol(tripulanteMbappe);

        Vuelo vuelo_maracana = new Vuelo(7);
        Ticket ticket1_VM = new Ticket(vuelo_maracana);
        Ticket ticket2_VM = new Ticket(vuelo_maracana);
        Vuelo vuelo_dubai = new Vuelo(14);
        Ticket ticket1_VD = new Ticket(vuelo_dubai);
        Ticket ticket2_VD = new Ticket(vuelo_maracana);

        ReciboSueldo recibo_messi = new ReciboSueldo(9999);
        recibo_messi.agregarVuelo(vuelo_maracana);

        ReciboSueldo recibo_mbappe = new ReciboSueldo(88888);
        recibo_mbappe.agregarVuelo(vuelo_maracana);
        recibo_mbappe.agregarVuelo(vuelo_dubai);

        tripulanteMessi.nuevoRecibo(recibo_messi);
        tripulanteMbappe.nuevoRecibo(recibo_mbappe);

        Rol pasajeroMessi = new Pasajero("7", ticket1_VD);
        messi.agregarRol(pasajeroMessi);

        Rol pasajeroMbappe = new Pasajero("19", ticket1_VM);
        messi.agregarRol(pasajeroMbappe);

        Rol pasajeroMbappe2= new Pasajero("7", ticket2_VD);
        mbappe.agregarRol(pasajeroMbappe2);

        vuelo_maracana.agregarPersona(messi);
        vuelo_maracana.agregarPersona(mbappe);
        vuelo_dubai.agregarPersona(mbappe);
        vuelo_dubai.agregarPersona(messi);

        messi.verRolesPersona();
        mbappe.verRolesPersona();
        neymar.verRolesPersona();

        System.out.println("\n<<<<<<<<<<<<<<>>>>>>>>>>>>\n");

        vuelo_maracana.verVuelo();
        System.out.println("<<<<<<<<<<<<<<>>>>>>>>>>>>\n");
        vuelo_dubai.verVuelo();

    }
}
