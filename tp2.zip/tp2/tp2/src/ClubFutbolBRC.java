import ClubFutbol.Personal;
import ClubFutbol.Socio;
import ClubFutbol.Suscripcion;

import java.util.Scanner;

public class ClubFutbolBRC {
    public static void main(String[] arg){
        Scanner sc = new Scanner(System.in);
        int cant, contador = 1;

        // damos de alta Personales

        Personal personal = new Personal("Jorge");
        Suscripcion suscripcion = new Suscripcion("");

        // damos de alta jugadores

        /*
        System.out.print("Ingrese la cantidad de socios que quiere dar de alta: ");
        cant = sc.nextInt();
        while(cant >= contador){
            String nombre="", apellido="", email="", sub="";

            System.out.println("Socio n" + contador);
            System.out.print("Nombre: ");
            nombre = sc.nextLine();
            System.out.print("Apellido: ");
            apellido = sc.nextLine();
            System.out.print("Email: ");
            email = sc.nextLine();
            System.out.print("Tipo de suscripcion: ");
            sub = sc.nextLine();

            Socio socio = new Socio(nombre, apellido, email);
            personal.nuevoSocio(socio, sub);
            contador++;
        }
        */
        Socio socio1 = new Socio("Gustavo", "Contardi", "litocontardi@yahoo.com");
        Socio socio2 = new Socio("Felipe", "Contardi", "gcontardi@gmail.com");
        Socio socio3 = new Socio("Federico", "Contardi", "fedecontardi@icloud.com");

        personal.nuevoSocio(socio1, "destacada");
        personal.nuevoSocio(socio2, "destacada");
        personal.nuevoSocio(socio3, "intermedio");

        personal.sociosInscriptos();
        System.out.println("\n");
        suscripcion.mostrar_actividades_sub("destacada");
        System.out.println("\n");
        personal.sociosPorSuscripcion("destacada");

    }
}
