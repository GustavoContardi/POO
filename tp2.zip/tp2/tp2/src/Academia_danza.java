import AcademiaDanza.*;

import java.util.ArrayList;

public class Academia_danza {
    public static void main(String[] args){
        Secretaria secretaria = new Secretaria();

        Alumno alumno1 = new Alumno("Gustavo", "gustavoa.contardi@gmail.com");
        Alumno alumno2 = new Alumno("Federico", "gustavoa.contardi@gmail.com");
        Alumno alumno3 = new Alumno("Gusatvo Andres", "gustavo.contardi@hotmail.com");

        Disciplina disciplina1 = new Disciplina("Danza Clasica", "Avanzada");
        Disciplina disciplina2 = new Disciplina("Reggeaton", "Inicial");

        ArrayList<String> dias = new ArrayList<>();
        dias.add("Lunes");
        dias.add("Miercoles");
        dias.add("Viernes");

        ArrayList<String> dias2 = new ArrayList<>();
        dias2.add("Lunes");
        dias2.add("Miercoles");
        dias2.add("Viernes");

        Profesor profesor1 = new Profesor("Pablo", disciplina1);
        Profesor profesor2 = new Profesor("Isabel", disciplina2);

        Diagramacion diagramacion1 = new Diagramacion("18 a 21", disciplina1, dias, profesor1);
        Diagramacion diagramacion2 = new Diagramacion("14 a 17", disciplina2, dias2, profesor2);
        secretaria.cargarDiagramaciones(diagramacion1);
        secretaria.cargarDiagramaciones(diagramacion2);

       // Credencial credencial1 = alumno1.getCredencial();
       // Credencial credencial2 = alumno2.getCredencial();

        diagramacion2.verDiasClases();
        System.out.println();
        diagramacion1.verDiasClases();

        secretaria.altaAlumno(alumno1, disciplina1);
        secretaria.altaAlumno(alumno2, disciplina2);

        for(int i=0; i<12; i++) secretaria.tomar_asistencia(alumno1.getCredencial());


        //System.out.println(alumno1.getCredencial().getDiasAsistibles());

        System.out.println("\n---\nasistencia alumno1: " + alumno1.getDiasAsistidos());

    }
}
