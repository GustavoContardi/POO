package FigurasGeometricas;

public abstract class Figura3D extends Figura {
    public abstract double getVolumen();
}
