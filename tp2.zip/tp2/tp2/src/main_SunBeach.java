import SunBeach_original.*;

public class main_SunBeach {
    public static void main(String[] args){
        Cliente cliente1 = new Cliente("Gustavo");
        Cliente cliente2 = new Cliente("Federico");
        Cliente cliente3 = new Cliente("Ricardo");

        Excursion excursion1 = new Excursion("Torre de pisa");
        Excursion excursion2 = new Excursion("Paracaidismo");
        Excursion excursion3 = new Excursion("Torre Eiffel");

        Transporte transporte1 = new Transporte("Avion");
        Transporte transporte3 = new Transporte("Ubber");
        Transporte transporte2 = new Transporte("Autobus");

        Hospedaje hospedaje1 = new Hospedaje("Hotel");
        Hospedaje hospedaje2 = new Hospedaje("Cabaña");
        Hospedaje hospedaje3 = new Hospedaje("Carpa");

        Administrador admin = new Administrador();
        admin.nuevo_viaje(transporte1, hospedaje2, excursion3);
        admin.nuevo_viaje(transporte3, hospedaje1, excursion2);
        admin.nuevo_viaje(transporte2, hospedaje3, excursion1);

        admin.mostrar_viajes();
        admin.vender_viaje(cliente1, 100);
        admin.vender_viaje(cliente1, 102);
        admin.vender_viaje(cliente2, 101);
        admin.vender_viaje(cliente2, 101);
        admin.vender_viaje(cliente3, 101);
        admin.total_ventas();
        System.out.println("\n----------------------");
        admin.viaje_mas_vendidos();
        System.out.println("\n\n");
        System.out.println("\n----------------------");
        admin.viaje_mas_vendidos();
    }
}
