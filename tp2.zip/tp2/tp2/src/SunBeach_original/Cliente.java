package SunBeach_original;

import java.util.ArrayList;

public class Cliente {
    private int id_cliente;
    private static int id_generico;
    private String nombre;
    private ArrayList<Paquete_turismo> viajes_comprados = new ArrayList<>();
    private Administrador admin;

    public Cliente(String nombre) {
        this.nombre = nombre;
        id_cliente = id_generico++;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId_cliente() {
        return id_cliente;
    }
}
