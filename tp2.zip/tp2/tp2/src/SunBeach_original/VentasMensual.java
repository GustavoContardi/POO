package SunBeach_original;

public class VentasMensual {
    private Cliente cliente;
    private Paquete_turismo paqueteTurismo;

    public VentasMensual(Cliente cliente, Paquete_turismo paqueteTurismo) {
        this.cliente = cliente;
        this.paqueteTurismo = paqueteTurismo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Paquete_turismo getPaqueteTurismo() {
        return paqueteTurismo;
    }
}
