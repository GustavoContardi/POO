package SunBeach_original;

public class Hospedaje {
    private String lugar;

    public Hospedaje(String lugar) {
        this.lugar = lugar;
    }

    public String getLugar() {
        return lugar;
    }
}
