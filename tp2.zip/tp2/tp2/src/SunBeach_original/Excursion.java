package SunBeach_original;

public class Excursion {
    private String nombre;

    public Excursion(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
