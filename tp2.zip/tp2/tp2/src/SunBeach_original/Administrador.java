package SunBeach_original;

import java.util.ArrayList;

public class Administrador {
    private static ArrayList<VentasMensual> totalVentas = new ArrayList<>();
    private Paquete_turismo viaje;
    private Cliente cliente;
    private ArrayList<Paquete_turismo> viajes = new ArrayList<>();


    public void nuevo_viaje(Transporte t, Hospedaje h, Excursion e){
        viaje = new Paquete_turismo(t, e, h);
        viajes.add(viaje);
    }

    public void mostrar_viajes(){
        System.out.println("\t\t ** VIAJES CONTARDI **\n");
        System.out.println("\tID \t EXCURSION \t TRANSPORTE\tHOSPEDAJE\n");
        for(int i=0; i<viajes.size(); i++){
            viaje = viajes.get(i);
            System.out.printf("\t* %d %s %s\t%s\n", viaje.getId_paquete(), viaje.getExcursion(), viaje.getTransporte(), viaje.getHospedaje());
        }
    }

    public void vender_viaje(Cliente cliente, int id_viaje){
        for(int i=0; i<viajes.size(); i++){
            viaje = viajes.get(i);
            if(viaje.getId_paquete() == id_viaje){
                viaje.sumar_venta();
                VentasMensual nueva_venta = new VentasMensual(cliente, viaje);
                totalVentas.add(nueva_venta);
            }
        }
    }

    public void viaje_mas_vendidos(){
        int n=0, id=0;
        String excursion = "";

        for (int i=0; i<viajes.size(); i++){
            viaje = viajes.get(i);
            if(viaje.getCantidad_ventas() > n){
                n = viaje.getCantidad_ventas();
                excursion = viaje.getExcursion();
            }
        }
        System.out.printf("El viaje mas vendido es: '%s', con %d ventas.", excursion, n);
    }

    public void total_ventas(){
        System.out.println("TOTAL VENTAS\n");
        System.out.println("ID \t NOMBRE\t ID VIAJE \t EXCURSION  \t HOTEL \t  TRANSPORTE");
        for (int i=0; i<totalVentas.size(); i++){
            VentasMensual ventas = totalVentas.get(i);
            viaje = ventas.getPaqueteTurismo();
            cliente = ventas.getCliente();
            System.out.printf("-%d\t %s \t  %d \t  %s  \t %s \t   %s\n", cliente.getId_cliente(), cliente.getNombre(), viaje.getId_paquete(), viaje.getExcursion(), viaje.getHospedaje(), viaje.getTransporte());
        }
    }
}
