package SunBeach_original;

public class Paquete_turismo {
    private int id_paquete;
    private static int id_generico = 100;
    private Transporte transporte;
    private Excursion excursion;
    private Hospedaje hospedaje;
    private int cantidad_ventas;

    public Paquete_turismo(Transporte transporte, Excursion excursion, Hospedaje hospedaje) {
        this.id_paquete = id_generico++ ;
        this.transporte = transporte;
        this.excursion = excursion;
        this.hospedaje = hospedaje;
        cantidad_ventas = 0;
    }

    public int getId_paquete() {
        return id_paquete;
    }

    public String getTransporte() {
        return transporte.getTransporte();
    }

    public String getExcursion() {
        return excursion.getNombre();
    }

    public String getHospedaje() {
        return hospedaje.getLugar();
    }

    public void sumar_venta(){
        cantidad_ventas++;
    }

    public int getCantidad_ventas() {
        return cantidad_ventas;
    }

}
