package SunBeach_original;

public class Transporte {
    private String transporte;
    public Transporte(String transporte) {
        this.transporte = transporte;
    }

    public String getTransporte() {
        return transporte;
    }
}
