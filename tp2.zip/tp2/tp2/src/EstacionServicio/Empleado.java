package EstacionServicio;

import java.util.ArrayList;
import java.util.Scanner;

public class Empleado {
    private static int id = 0;
    private int id_empleado;
    private String nombre;
    private String apellido;
    private String dni;
    private String domicilio;
    private String telefono;
    private double montoTotal = 0;
    private boolean Descuento;

    public Empleado(String nombre, String apellido, String dni, String domicilio, String telefono) {
        id += 1;
        this.id_empleado = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.domicilio = domicilio;
        this.telefono = telefono;
    }
    public Empleado(String nombre, String apellido) {
        id += 1;
        this.id_empleado = id;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    public void setDescuento(boolean Descuento) {
        this.Descuento = Descuento;
    }

    void realizarDescuentoCliente(int cantLitrosCarga, Surtidor expendedor) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Cliente> clientes = Informe.getClientes();
        Cliente cliente = null;
        for (Cliente c: clientes) {
            System.out.println("Nombre: " + c.getNombre() + " ID: " + c.getIdCliente());
        }
        System.out.println("Ingrese el ID del cliente a realizar el descuento");
        int clienteid = sc.nextInt();
        for (Cliente c: clientes) {
            if (c.getIdCliente() == clienteid) {
                cliente = c;
            }
        }
        atenderCliente(cliente, cantLitrosCarga, expendedor, true);


    }
    public void atenderCliente(Cliente cliente, int cantLitrosCarga, Surtidor Surtidor, boolean descuento10) {
        Combustible combustible = Surtidor.getTipo();
        ArrayList<Integer> topCliente = Informe.getClientesTop10();
        double totalVenta = combustible.getPrecioVenta() * cantLitrosCarga;
        if (topCliente.contains(cliente.getIdCliente())) {
            double descuento = 0.05 * totalVenta;
            totalVenta -= descuento;
        }
        if (descuento10) {
            double descuento10Porc = 0.10 * totalVenta;
            totalVenta -= descuento10Porc;
            System.out.println("Descuento realizado con exito.");
        }
        Surtidor.setLitrosExpulsados(Surtidor.getLitrosExpulsados() + cantLitrosCarga);
        Venta venta = new Venta(id_empleado, cliente.getIdCliente(), combustible, totalVenta);
        montoTotal += totalVenta;
        Surtidor.setCantVentas(Surtidor.getCantVentas() + 1);
        Informe.agregarVentas(venta);
        Informe.agregarExpendedores(Surtidor);
        cliente.setMontoTotalCompra(cliente.getMontoTotalCompra() + totalVenta);
        Informe.agregarClientes(cliente);
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
