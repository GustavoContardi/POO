package EstacionServicio;

public class Venta {
    private int idEmpleado;
    private int idCliente;
    private Combustible tipo;
    private double totalVenta;
    public Venta(int idEmpleado, int idCliente, Combustible tipo, double totalVenta) {
        this.idCliente = idCliente;
        this.idEmpleado = idEmpleado;
        this.tipo = tipo;
        this.totalVenta = totalVenta;
    }

    public int getIdPlayero() {
        return idEmpleado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public Combustible getTipo() {
        return tipo;
    }

    public double getTotalVenta() {
        return totalVenta;
    }
}
