package EstacionServicio;

public class Surtidor {
    private static int nro = 0;
    private int nroExpendedor;
    private Combustible combustible;
    private int totalLitros;
    private int litrosExpulsados = 0;
    private int cantVentas;

    public Surtidor(Combustible combustible, int totalLitros) {
        this.combustible = combustible;
        this.totalLitros = totalLitros;
        nro += 1;
        nroExpendedor = nro;
    }

    public int getNroExpendedor() {
        return nroExpendedor;
    }

    public Combustible getTipo() {
        return combustible;
    }

    public void setTipo(Combustible combustible) {
        this.combustible = combustible;
    }

    public int getTotalLitros() {
        return totalLitros;
    }

    public void setTotalLitros(int totalLitros) {
        this.totalLitros = totalLitros;
    }

    public int getLitrosExpulsados() {
        return litrosExpulsados;
    }

    void setLitrosExpulsados(int litrosExpulsados) {
        this.litrosExpulsados = litrosExpulsados;
    }

    public int getCantVentas() {
        return cantVentas;
    }

    void setCantVentas(int cantVentas) {
        this.cantVentas = cantVentas;
    }
}
