import FigurasGeometricas.*;

import java.util.Scanner;

public class main_figuras {
    //public static void MenuEjercicio9 () {
    public static void main(String[] argumentos) {
        Scanner scanner = new Scanner(System.in);

        //CIRCULO (radio)
        System.out.print("Ingrese el radio del círculo: ");
        double radioCirculo = scanner.nextDouble();
        Circulo circulo = new Circulo(radioCirculo);
        double areaCirculo = circulo.getArea();
        System.out.println("El área del círculo es: " + areaCirculo);

        //RECTANGULO (base, altura)
        System.out.print("Ingrese la base del rectangulo: ");
        double baseRectangulo = scanner.nextDouble();
        System.out.print("Ingrese la altura del rectangulo: ");
        double alturaRectangulo = scanner.nextDouble();
        Rectangulo rectangulo = new Rectangulo(baseRectangulo, alturaRectangulo);
        double areaRectangulo = rectangulo.getArea();
        System.out.println("El área del rectangulo es: " + areaRectangulo);

        //CUADRADO (lado)
        System.out.print("Ingrese la longitud de lado del cuadrado: ");
        double ladoCuadrado = scanner.nextDouble();
        Cuadrado cuadrado = new Cuadrado(ladoCuadrado);
        double areaCuadrado = cuadrado.getArea();
        System.out.println("El área del cuadrado es: " + areaCuadrado);

        //TRIANGULO (base, altura)
        System.out.print("Ingrese la base del triangulo: ");
        double baseTriangulo = scanner.nextDouble();
        System.out.print("Ingrese la altura del triangulo: ");
        double alturaTriangulo = scanner.nextDouble();
        Triangulo triangulo = new Triangulo(baseTriangulo, alturaTriangulo);
        double areaTriangulo = triangulo.getArea();
        System.out.println("El área del triangulo es: " + areaTriangulo);

        //CUBO (arista)
        System.out.print("Ingrese la arista del cubo: ");
        double aristaCubo = scanner.nextDouble();
        Cubo cubo = new Cubo(aristaCubo);
        double areaCubo = cubo.getArea();
        System.out.println("El área del cubo es: " + areaCubo);

        //ESFERA (radio)
        System.out.print("Ingrese el radio de la esfera: ");
        double radioEsfera = scanner.nextDouble();
        Esfera esfera = new Esfera(radioEsfera);
        double areaEsfera = esfera.getArea();
        System.out.println("El área de la esfera es: " + areaEsfera);

        //PARALELEPIPEDO (arista1, arista2, arista3)
        System.out.print("Ingrese la arista N°1 del paralelepipedo: ");
        double arista1 = scanner.nextDouble();
        System.out.print("Ingrese la arista N°2 del paralelepipedo: ");
        double arista2 = scanner.nextDouble();
        System.out.print("Ingrese la arista N°3 del paralelepipedo: ");
        double arista3 = scanner.nextDouble();
        Paralelepipedo paralelepipedo = new Paralelepipedo(arista1, arista2, arista3);
        double areaParalelepipedo = paralelepipedo.getArea();
        System.out.println("El área del paralelepipedo es: " + areaParalelepipedo);

        //TETRAEDRO (arista)
        System.out.print("Ingrese la arista del tetraedro: ");
        double aristaTetraedro = scanner.nextDouble();
        Tetraedro tetraedro = new Tetraedro(aristaTetraedro);
        double areaTetraedro = tetraedro.getArea();
        System.out.println("El área del tetraedro es: " + areaTetraedro);

        System.out.println("VOLUMENES\n");

        //CUBO (arista)
        System.out.print("Ingrese la arista del cubo: ");
        aristaCubo = scanner.nextDouble();
        cubo = new Cubo(aristaCubo);
        double volumenCubo = cubo.getVolumen();
        System.out.println("El volumen del cubo es: " + volumenCubo);

        //ESFERA (radio)
        System.out.print("Ingrese el radio de la esfera: ");
        radioEsfera = scanner.nextDouble();
        esfera = new Esfera(radioEsfera);
        double volumenEsfera = esfera.getVolumen();
        System.out.println("El volumen de la esfera es: " + volumenEsfera);

        //PARALELEPIPEDO (arista1, arista2, arista3)
        System.out.print("Ingrese la arista 1 del paralelepipedo: ");
        arista1 = scanner.nextDouble();
        System.out.print("Ingrese la arista 2 del paralelepipedo: ");
        arista2 = scanner.nextDouble();
        System.out.print("Ingrese la arista 3 del paralelepipedo: ");
        arista3 = scanner.nextDouble();
        paralelepipedo = new Paralelepipedo(arista1, arista2, arista3);
        double volumenParalelepipedo = paralelepipedo.getVolumen();
        System.out.println("El volumen del paralelepipedo es: " + volumenParalelepipedo);

        //TETRAEDRO (arista)
        System.out.print("Ingrese la arista del tetraedro: ");
        aristaTetraedro = scanner.nextDouble();
        tetraedro = new Tetraedro(aristaTetraedro);
        double volumenTetraedro = tetraedro.getVolumen();
        System.out.println("El volumen del tetraedro es: " + volumenTetraedro);

    }

}
