import Controladores.Controlador1;
import Modelos.Anotador;
import Modelos.Jugador;
import Modelos.Mazo;
import Vistas.ConsolaGrafica.Consola;
import Vistas.ConsolaGrafica.PuntajePartida;
import Vistas.IVista;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Mazo mazo = new Mazo();
        Jugador j1 = new Jugador("Messi");
        Jugador j2 = new Jugador("CR7");
        mazo.repartirCartas(j1, j2);
        Anotador anotador = new Anotador(j1, j2);

        Consola consola2 = new Consola(j1, j2, anotador);
        Consola consola = new Consola(j1, j2, anotador);

        consola.setConsolaOb(consola2);
        consola2.setConsolaOb(consola);

        Controlador1 controlador1 = new Controlador1(j1, consola);
        Controlador1 controlador2 = new Controlador1(j2, consola2);
        PuntajePartida puntajePartida = new PuntajePartida(j1, j2);

        anotador.agregarObservador(consola2);
        anotador.agregarObservador(consola);
        anotador.agregarObservador(puntajePartida);

        controlador1.setAnotador(anotador);
        controlador2.setAnotador(anotador);

        puntajePartida.verPuntajes();
        consola2.mostrarMenuPrincipal();
        consola.mostrarMenuPrincipal();


        System.out.println("pts j1: " + controlador1.ptoEnvido());
        System.out.println("pts j2: " + controlador2.ptoEnvido());
    }
}

