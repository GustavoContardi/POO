package Modelos;

import Observer.Observer;
import Observer.ObjetoObservable;

import java.util.ArrayList;

public class Anotador implements ObjetoObservable {
    private static ArrayList<Observer> observadores = new ArrayList<>();
    private int puntajeJ1 = -1;
    private int puntajeJ2 = -1;
    private Jugador j1;
    private Jugador j2;

    public Anotador(Jugador j2, Jugador j1) {
        if(puntajeJ2 == -1 && puntajeJ1 == -1) {
            puntajeJ2 = 0;
            puntajeJ1 = 0;
        }
        this.j1 = j1;
        this.j2 = j2;
    }

    public void sumarJ1(int cant){
        puntajeJ1 += cant;
        notificarPuntos(cant, 0);
    }

    public void sumarJ2(int cant){
        puntajeJ2 += cant;
        notificarPuntos(0, cant);
    }

    public int getPuntajeJ1() {
        return puntajeJ1;
    }

    public int getPuntajeJ2() {
        return puntajeJ2;
    }

    public Jugador getJ1() {
        return j1;
    }

    public Jugador getJ2() {
        return j2;
    }


    @Override
    public void agregarObservador(Observer observer) {
        observadores.add(observer);
    }

    @Override
    public void quitarObservador(Observer observer) {
        observadores.remove(observer);
    }

    @Override
    public void notificarObservadores() {
        for (Observer observer: observadores) {
            observer.actualizar();
        }
    }

    @Override
    public void notificarCartaTirada(Carta carta) {

    }

    @Override
    public void enviarMensaje(String mensaje) {

    }

    @Override
    public void notificarCanto(int mensaje) {

    }

    @Override
    public void notificarPuntos(int j1, int j2) {
        for (Observer observer: observadores) {
            observer.actualizarPuntos(j1, j2);
        }
    }


}
