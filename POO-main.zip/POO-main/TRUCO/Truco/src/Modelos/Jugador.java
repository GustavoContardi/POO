package Modelos;

import Observer.ObjetoObservable;
import Observer.Observer;

import java.util.ArrayList;

public class Jugador implements ObjetoObservable {
    private String nombre;
    private int partidasGanadasTotal;
    private ArrayList<Carta> cartasRepartidas = new ArrayList<>();
    private static ArrayList<Jugador> jugadoresActuales = new ArrayList<>();
    private static ArrayList<Observer> observadores = new ArrayList<>();
    private ArrayList<Carta> cartasRepartidasCopia = new ArrayList<>();
    private Cantar cantar;


    public Jugador(String nombre) {
        this.nombre = nombre;
        cantar = new Cantar();
    }

    public void recibirCartas(ArrayList<Carta> cartas){
        cartasRepartidas = cartas;
        cartasRepartidasCopia = cartas;
        notificarObservadores();
    }

    public void devolverCartas(){
        cartasRepartidas.clear();
    }

    public ArrayList<Carta> getCartasRepartidas() {
        return cartasRepartidasCopia;
    }
    public ArrayList<Carta> ObtenerCartasRepartidas() {
        return cartasRepartidas;
    }



    public String getNombre() {
        return nombre;
    }


    public boolean tieneFlor(){
        boolean result = false;
        if(cartasRepartidas != null){
            if(cartasRepartidas.get(0).getPalo().equals(cartasRepartidas.get(1).getPalo()) && cartasRepartidas.get(0).getPalo().equals(cartasRepartidas.get(2).getPalo())){
                result = true;
            }
        }
        return result;
    }


    public Carta tirarCarta(int numero){
        // siempre y cuando sea un numero entre 1 y 3
        Carta tirada = cartasRepartidas.get(numero-1);
        cartasRepartidas.remove(cartasRepartidas.get(numero-1));
        notificarCartaTirada(tirada);
        return tirada;
    }

    public String cantarTruco(){
        enviarMensaje(nombre + ": " + cantar.cantarTruco());
        return cantar.cantarTruco();
    }

    public String cantarEnvido(){
        notificarCanto(1);
        enviarMensaje(nombre + ": " +cantar.cantarEnvido());
        return cantar.cantarEnvido();
    }
    public String cantarReTruco(){
        enviarMensaje(nombre + ": " + cantar.cantarReTruco());
        return cantar.cantarReTruco();
    }
    public String cantarRealEnvido(){
        notificarCanto(3);
        enviarMensaje(nombre + ": " + cantar.cantarRealEnvido());
        return cantar.cantarRealEnvido();
    }
    public String cantarFaltaEnvido(){
        notificarCanto(4);
        enviarMensaje(nombre + ": " + cantar.cantarFaltaEnvido());
        return cantar.cantarFaltaEnvido();
    }
    public String cantarVC(){
        enviarMensaje(nombre + ": " + cantar.cantarValeCuatro());
        return cantar.cantarValeCuatro();
    }
    public String cantarIrseAlMazo(){
        enviarMensaje(nombre + ": " + cantar.cantarMeVoyAlMazo());
        return cantar.cantarMeVoyAlMazo();
    }
    public String cantarQuiero(){
        enviarMensaje(nombre + ": " + "QUIERO");
        return  "";
    }
    public String mostrarAlgo(String msj){
        enviarMensaje(msj);
        return "";
    }



    @Override
    public void agregarObservador(Observer observer) {
        observadores.add(observer);
    }

    @Override
    public void quitarObservador(Observer observer) {
        observadores.remove(observer);
    }

    @Override
    public void notificarObservadores() {
        for (Observer observer: observadores) {
            observer.actualizar();
        }
    }

    @Override
    public void notificarCartaTirada(Carta carta) {
        for (Observer observer: observadores) {
            observer.actualizarCartas();
        }
    }

    @Override
    public void enviarMensaje(String mensaje) {
        for (Observer observer: observadores) {
            observer.enviarMensaje(mensaje);
        }
    }

    @Override
    public void notificarCanto(int mensaje) {
        for (Observer observer: observadores) {
            observer.recibirCanto(mensaje);
        }
    }

    @Override
    public void notificarPuntos(int j1, int j2) {

    }


    public void agregarJugador(Jugador j){
        jugadoresActuales.add(j);
    }



}
