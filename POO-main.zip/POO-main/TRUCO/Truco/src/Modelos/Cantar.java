package Modelos;

public class Cantar {

    private String truco = "\n¿estamos jugando al truco, no?\n";
    private String retruco = "\n¡QUIERO RETRUCO!\n";
    private String valeCuatro = "\nYo no me achico, ¡VALE CUATRO!\n";
    private String envido = "\nEnvido!\n";
    private String realEnvido = "\n¡Real envido!\n";
    private String faltaEnvido = "\nTiro la casa por la ventana, ¡FALTA ENVIDO!\n";
    private String flor = "\nQue flor de tormenta la de anoche...\n";
    private String meVoyAlMazo = "\nMe fui al mazooo...\n";

    public Cantar() {
        truco = "¿estamos jugando al truco, no?\n";
        retruco = "¡QUIERO RETRUCO!\n";
        valeCuatro = "Yo no me achico, ¡VALE CUATRO!\n";
        envido = "Envido!\n";
        realEnvido = "¡Real envido!\n";
        faltaEnvido = "Tiro la casa por la ventana, ¡FALTA ENVIDO!\n";
        flor = "Que FLOR de tormenta la de anoche...\n";
        meVoyAlMazo = "Me fui al mazooo...\n";
    }

    public String cantarTruco(){
        return truco;
    }
    public String cantarReTruco(){
        return retruco;
    }
    public String cantarValeCuatro(){
        return valeCuatro;
    }
    public String cantarEnvido(){
        return envido;
    }public String cantarRealEnvido(){
        return realEnvido;
    }
    public String cantarFaltaEnvido(){
        return faltaEnvido;
    }
    public String cantarFlor(){
        return flor;
    }
    public String cantarMeVoyAlMazo(){
        return meVoyAlMazo;
    }
}
