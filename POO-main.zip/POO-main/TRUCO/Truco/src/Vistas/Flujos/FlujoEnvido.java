package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoEnvido extends Flujo{
    private boolean turno;
    public FlujoEnvido(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
    }

    @Override
    public Flujo procesarEntrada(String string) {
        switch (string){
            case "1" -> {
                vista.limpiarPantalla();
                procesarEnvido();
                vista.recibirCanto(1);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);

            }
            case "2" ->{
                procesarRealEnvido();
                vista.recibirCanto(3);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
            case "3" ->{
                procesarFaltaEnvido();
                vista.recibirCanto(4);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
            case "4" -> {
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
        }

        return this;
    }

    private void procesarEnvido(){
        controlador.cantar("Envido");
        turno = false;
    }
    private void procesarRealEnvido(){
        controlador.cantar("Real Envido");
        turno = false;
    }
    private void procesarFaltaEnvido(){
        controlador.cantar("falta envido");
        turno = false;
    }

    @Override
    public void mostrarSiguienteTexto() {
        vista.println("1- Envido | 2- Real Envido | 3- Falta Envido | 4- Volver");
    }
}
