package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoTruco extends Flujo{

    public FlujoTruco(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
    }

    @Override
    public Flujo procesarEntrada(String string) {
        String result = vista.estadoTruco();
        switch (result){
            case "truco"->{
                procesarTruco();
                vista.setEstadoTruco("truco");
                vista.recibirCanto(6);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
            case "retruco"->{
                vista.setEstadoTruco("retruco");
                procesarReTruco();
                vista.recibirCanto(7);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
            case "valecuatro"->{
                procesarValeCuatro();
                vista.setEstadoTruco("valecuatro");
                vista.recibirCanto(8);
                vista.limpiarPantalla();
                return new FlujoMostrarCartas(vista, controlador);
            }
        }
        return this;
    }

    private void procesarTruco(){
        controlador.cantar("truco");
    }
    private void procesarReTruco(){
        controlador.cantar("retruco");
    }
    private void procesarValeCuatro(){
        controlador.cantar("valecuatro");
    }

    @Override
    public void mostrarSiguienteTexto() {
        String result = vista.estadoTruco();
        switch (result){

        }
    }
}
