package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public abstract class Flujo {
    protected final Consola vista;
    protected final Controlador1 controlador;

    public Flujo(Consola vista, Controlador1 controlador) {
        this.vista = vista;
        this.controlador = controlador;
    }

    public abstract Flujo procesarEntrada(String string);

    public abstract void mostrarSiguienteTexto();

}
