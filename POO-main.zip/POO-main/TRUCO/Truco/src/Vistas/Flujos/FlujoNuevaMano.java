package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoNuevaMano extends Flujo{
    public FlujoNuevaMano(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
    }

    @Override
    public Flujo procesarEntrada(String string) {
        return new FlujoMostrarCartas(vista, controlador);
    }

    @Override
    public void mostrarSiguienteTexto() {

    }
}
