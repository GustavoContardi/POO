package Vistas.Flujos;

import Controladores.Controlador1;
import Modelos.Carta;
import Vistas.ConsolaGrafica.Consola;

public class FlujoTirarCartas extends Flujo{
    private boolean turno;
    public FlujoTirarCartas(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
        turno = true;
    }

    @Override
    public Flujo procesarEntrada(String string) {
        switch (string){
            case("1") -> procesarCarta(string);
            case("2") -> procesarCarta(string);
            case("3") -> procesarCarta(string);
        }
        return new FlujoMostrarCartas(vista, controlador);
    }

    private Flujo procesarCarta(String string){
        Integer numero;
        Carta carta;
        try{
            numero = Integer.parseInt(string);
            if(numero < 1 || numero > controlador.verCartasRepartidas().size()){
                vista.println("Ingrese un valor > 1 o < 3");
            }
            else if(!turno) {
                vista.limpiarPantalla();
                vista.println("No es tu turno");
            }
            else{
                vista.limpiarPantalla();
                carta = controlador.tirarCarta(numero);
                vista.println("Tiraste: " + carta.getNumero() + " de " + carta.getPalo());
                vista.enviarMensaje(carta.getNumero() + " de " + carta.getPalo());

                return new FlujoMostrarCartas(vista, controlador);
            }
        }catch (NumberFormatException e){
            vista.println("Ingrese un número válido.");
        }
        return this;
    }

    @Override
    public void mostrarSiguienteTexto() {
        vista.println("Elije una carta para tirar: ");
    }
}
