package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoEleccionTruco extends Flujo{
    enum EstadosPosibles {
        TRUCO,
        RETRUCO,
        VALECUATRO,
    }

    private EstadosPosibles estadosActual;

    public void setEstado(int estado){
        if(estado == 6) estadosActual = EstadosPosibles.TRUCO;
        else if(estado == 7) estadosActual = EstadosPosibles.RETRUCO;
        else if(estado == 8) estadosActual = EstadosPosibles.VALECUATRO;
    }

    public FlujoEleccionTruco(Consola vista, Controlador1 controlador, int estado) {
        super(vista, controlador);
        setEstado(estado);
    }

    @Override
    public Flujo procesarEntrada(String string) {
        switch (estadosActual){
            case TRUCO -> {
               switch (string){
                   case "1" -> {
                       vista.limpiarPantalla();
                       controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");

                       return new FlujoMostrarCartas(vista, controlador);
                   }
                   case "2" -> {
                       vista.limpiarPantalla();
                       controlador.enviarMensaje(controlador.nomJug() + ": ¡NO QUIERO!");
                       controlador.enviarMensaje("Fin de la mano");
                       vista.setFinMano();
                       vista.nuevaMano();
                   }
                   case "3" ->{
                       vista.limpiarPantalla();
                       procesarReTruco();
                       vista.recibirCanto(7);
                       return new FlujoMostrarCartas(vista, controlador);
                   }
               }
            }
            case RETRUCO -> {
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "2" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡NO QUIERO!");
                        controlador.enviarMensaje("Fin de la mano");
                        vista.setFinMano();
                        vista.nuevaMano();
                    }
                    case "3" ->{
                        vista.limpiarPantalla();
                        procesarValeCuatro();
                        vista.recibirCanto(8);
                        vista.limpiarPantalla();
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
            case VALECUATRO -> {
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        vista.nuevaMano();
                    }
                    case "2" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡NO QUIERO!");
                        controlador.enviarMensaje("Fin de la mano");
                        vista.setFinMano();
                        vista.nuevaMano();
                    }
                }
            }
        }
        return this;
    }
    private void procesarTruco(){
        controlador.cantar("truco");
    }
    private void procesarReTruco(){
        controlador.cantar("retruco");
    }
    private void procesarValeCuatro(){
        controlador.cantar("vale cuatro");
    }

    @Override
    public void mostrarSiguienteTexto() {
        switch (estadosActual){
            case TRUCO      ->  vista.println("1- Quiero | 2- No quiero | 3- RETRUCO ");
            case RETRUCO    ->  vista.println("1- Quiero | 2- No quiero | 4- VALECUATRO");
            case VALECUATRO ->  vista.println("1- Quiero | 2- No quiero");
        }
    }
}
