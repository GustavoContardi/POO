package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoAltaJugador extends Flujo {
    public FlujoAltaJugador(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
    }

    @Override
    public Flujo procesarEntrada(String string) {

        return this;
    }

    @Override
    public void mostrarSiguienteTexto() {
        vista.println("Ingrese el nombre");
    }
}
