package Vistas.Flujos;

import Controladores.Controlador1;
import Vistas.ConsolaGrafica.Consola;

public class FlujoEleccionEnvido extends Flujo{
    enum EstadosPosibles {
        ENVIDO,
        ENVIDODOBLE,
        REAL_ENVIDO,
        FALTA_ENVIDO,
    }

    private EstadosPosibles estadosActual;
    private static int ptsSiQuiere, ptsSiNoQuiere;

    public void setEstado(int estado){
        if(estado == 1) estadosActual = EstadosPosibles.ENVIDO;
        else if(estado == 2) estadosActual = EstadosPosibles.ENVIDODOBLE;
        else if(estado == 3) estadosActual = EstadosPosibles.REAL_ENVIDO;
        else if(estado == 4) estadosActual = EstadosPosibles.FALTA_ENVIDO;
    }

    public FlujoEleccionEnvido(Consola vista, Controlador1 controlador, int estado) {
        super(vista, controlador);
        setEstado(estado);
        ptsSiQuiere =0;
        ptsSiNoQuiere =0;
    }

    @Override
    public Flujo procesarEntrada(String string) {
        switch (estadosActual){
            case ENVIDO ->{
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        controlador.enviarMensaje(vista.envido(2)+"\n");
                        return new FlujoMostrarCartas(vista, controlador);
                    }

                    case "2" ->{
                        vista.limpiarPantalla();
                        vista.println(controlador.nomJug() + ": No Quiero");
                        controlador.sumarPuntos(1, controlador.getModelo());
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "3"->{
                        vista.limpiarPantalla();
                        procesarEnvido();
                        estadosActual = EstadosPosibles.ENVIDODOBLE;
                        vista.recibirCanto(2);
                        ptsSiQuiere=4;
                        ptsSiNoQuiere=2;
                        vista.limpiarPantalla();
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "4" ->{
                        vista.limpiarPantalla();
                        procesarRealEnvido();
                        ptsSiQuiere=5;
                        ptsSiNoQuiere=2;
                        vista.recibirCanto(3);
                        vista.limpiarPantalla();

                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "5" -> {
                        vista.limpiarPantalla();
                        procesarFaltaEnvido();
                        vista.recibirCanto(4);
                        ptsSiQuiere=30;
                        ptsSiNoQuiere=2;
                        vista.limpiarPantalla();
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
            case ENVIDODOBLE ->{
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        controlador.enviarMensaje(vista.envido(4)+"\n");
                        ptsSiQuiere=4;
                        ptsSiNoQuiere=2;
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "2" -> {
                        vista.limpiarPantalla();
                        vista.println(controlador.nomJug() + ": No Quiero");
                        controlador.sumarPuntos(ptsSiNoQuiere, controlador.getModelo());
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "4" -> {
                        vista.limpiarPantalla();
                        procesarRealEnvido();
                        vista.recibirCanto(3);
                        vista.limpiarPantalla();
                        ptsSiQuiere=7;
                        ptsSiNoQuiere=4;
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "5" -> {
                        vista.limpiarPantalla();
                        procesarFaltaEnvido();
                        vista.recibirCanto(4);
                        ptsSiQuiere=30;
                        ptsSiNoQuiere=4;
                        vista.limpiarPantalla();
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
            case REAL_ENVIDO -> {
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        controlador.enviarMensaje(vista.envido(3)+"\n");
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "2" -> {
                        vista.limpiarPantalla();
                        vista.println(controlador.nomJug() + ": No Quiero");
                        controlador.sumarPuntos(ptsSiNoQuiere, controlador.getModelo());
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "5" -> {
                        vista.limpiarPantalla();
                        procesarFaltaEnvido();
                        vista.recibirCanto(4);
                        ptsSiQuiere=30;
                        ptsSiNoQuiere=5;
                        vista.limpiarPantalla();
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
            case FALTA_ENVIDO -> {
                switch (string){
                    case "1" -> {
                        vista.limpiarPantalla();
                        controlador.enviarMensaje(controlador.nomJug() + ": ¡QUIERO!");
                        controlador.enviarMensaje(vista.envido(30)+"\n");
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "2" -> {
                        vista.limpiarPantalla();
                        vista.println(controlador.nomJug() + ": No Quiero");
                        controlador.sumarPuntos(ptsSiNoQuiere, controlador.getModelo());
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
        }
        return this;
    }
    private void procesarEnvido(){
        controlador.cantar("Envido");
    }
    private void procesarRealEnvido(){
        controlador.cantar("Real Envido");
    }
    private void procesarFaltaEnvido(){
        controlador.cantar("falta envido");
    }

    @Override
    public void mostrarSiguienteTexto() {
        switch (estadosActual){
            case ENVIDO       ->  vista.println("1- Quiero | 2- No quiero | 3- Envido | 4- Real Envido | 5- Falta Envido");
            case ENVIDODOBLE  ->  vista.println("1- Quiero | 2- No quiero | 4- Real Envido | 5- Falta Envido");
            case REAL_ENVIDO  ->  vista.println("1- Quiero | 2- No quiero | 5- Falta Envido");
            case FALTA_ENVIDO ->  vista.println("1- Quiero | 2- No quiero");
        }
    }
}
