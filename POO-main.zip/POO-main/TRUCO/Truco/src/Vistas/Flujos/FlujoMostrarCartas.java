package Vistas.Flujos;

import Controladores.Controlador1;
import Modelos.Carta;
import Vistas.ConsolaGrafica.Consola;

import java.util.ArrayList;

public class FlujoMostrarCartas extends Flujo{
    private ArrayList<Carta> cartas = new ArrayList<>();
    public FlujoMostrarCartas(Consola vista, Controlador1 controlador) {
        super(vista, controlador);
    }

    private int opcion = 0;

    @Override
    public Flujo procesarEntrada(String string) {
        switch (string){
            case "1" ->{
                return new FlujoEnvido(vista, controlador);
            }
            case "2" -> {
                String result = vista.estadoTruco();
                switch (result){
                    case "truco"->{
                        procesarTruco();
                        vista.setEstadoTruco("truco");
                        vista.recibirCanto(6);
                        vista.limpiarPantalla();
                        vista.setSeCantoEnvido(true);
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "retruco"->{
                        vista.setEstadoTruco("retruco");
                        procesarReTruco();
                        vista.recibirCanto(7);
                        vista.limpiarPantalla();
                        vista.setSeCantoEnvido(true);
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                    case "valecuatro"->{
                        procesarValeCuatro();
                        vista.setEstadoTruco("valecuatro");
                        vista.recibirCanto(8);
                        vista.limpiarPantalla();
                        vista.setSeCantoEnvido(true);
                        return new FlujoMostrarCartas(vista, controlador);
                    }
                }
            }
            case "3" -> {
                return new FlujoTirarCartas(vista, controlador);
            }
            case "4" -> {
                vista.println("CHAU");
                vista.setFinMano();
                vista.nuevaMano();
            }
        }

        return this;
    }

    @Override
    public void mostrarSiguienteTexto() {
        int p = 1;
        cartas = controlador.verCartasRepartidas();
        vista.println("Cartas de: " + controlador.nomJug());
        for(int i=0; i<cartas.size(); i++){
            vista.println(p+"- " + cartas.get(i).getNumero() + " de " + cartas.get(i).getPalo());
            p++;
        }
        String result = vista.estadoTruco();
        switch (result){
            case "truco"->{
                opcion = 6;
                if(vista.getSeCantoEnvido()) vista.println("\n2. Truco | 3. Tirar carta | 4. Irse al mazo");
                else vista.println("\n1. Envido | 2. Truco | 3. Tirar carta | 4. Irse al mazo");
            }
            case "retruco" -> {
                vista.println("\n2. Re Truco | 3. Tirar carta | 4. Irse al mazo");
                opcion = 7;
            }
            case "valecuatro" -> {
                opcion = 8;
                vista.println("\n2. Vale Cuatro | 3. Tirar carta | 4. Irse al mazo");
            }
            case "nada" -> vista.println("\n3. Tirar carta | 4. Irse al mazo");
        }
    }

    private void procesarTruco(){
        controlador.cantar("truco");
    }
    private void procesarReTruco(){
        controlador.cantar("retruco");
    }
    private void procesarValeCuatro(){
        controlador.cantar("valecuatro");
    }


}
