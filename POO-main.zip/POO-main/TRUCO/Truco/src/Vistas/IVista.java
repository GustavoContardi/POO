package Vistas;

import Controladores.*;
import Modelos.Jugador;

public interface IVista {
    void setControlador(Controlador1 controlador);

    void mostrarCartasRepartidas();
    void mostrarPuntaje();
    void mostrarAccionInvalida();
    void tirarCartas();

    void mostrarMenuPrincipal();

}
