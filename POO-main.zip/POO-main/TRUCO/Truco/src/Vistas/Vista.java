package Vistas;

public abstract class Vista {
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
