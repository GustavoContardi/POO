package Vistas.ConsolaGrafica;

import Controladores.*;
import Modelos.Anotador;
import Modelos.Envido;
import Modelos.Jugador;
import Modelos.Mazo;
import Observer.Observer;
import Vistas.Flujos.*;
import Vistas.IVista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Consola implements IVista, Observer{
    private Jugador j1;
    private Jugador j2;

    private JPanel ventana;
    private JButton btnEnter;
    private JTextArea areaTexto;
    private JScrollPane scroll;
    private JTextField txtEntrada;
    private final JFrame frame;

    private Controlador1 controlador;

    Flujo flujoActual;

    private static int contadorMano;
    private static int nroRonda;
    private boolean finMano, finPartida;
    private int puntosJ1;
    private int puntosJ2;
    private Anotador anotador;

    private boolean seCantoEnvido, seCantoTruco, seCantoReTruco, seCantoValeCuatro;


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    public Consola(Jugador j1, Jugador j2, Anotador anotador) {
        frame = new JFrame("TRUCONTARDI");
        frame.setContentPane(ventana);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(500, 350);

        btnEnter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                areaTexto.append(txtEntrada.getText() + "\n");
                procesarEntrada(txtEntrada.getText());
                txtEntrada.setText("");
            }
        });
        this.j1 = j1;
        contadorMano = 1;
        this.j2 = j2;

        puntosJ1=0;
        puntosJ2=0;
        this.anotador = anotador;
        anotador.agregarObservador(this);

        seCantoValeCuatro=false;
        seCantoTruco=false;
        seCantoEnvido=false;
        seCantoReTruco=false;
    }

    private void procesarEntrada(String input) {
        input = input.trim();
        if (input.isEmpty()) {
            return;
        }
        flujoActual = flujoActual.procesarEntrada(input);
        flujoActual.mostrarSiguienteTexto();
    }

    public void mostrar() {
        frame.setVisible(true);
    }
    public void println(String texto) {
        areaTexto.append(texto + "\n");
    }



    public void setConsolaOb(Consola c){
        j1.agregarObservador(c);
    }
    @Override
    public void setControlador(Controlador1 controlador) {
        this.controlador = controlador;
    }

    @Override
    public void mostrarCartasRepartidas() {
    }

    @Override
    public void mostrarPuntaje() {

    }

    @Override
    public void mostrarAccionInvalida() {

    }

    @Override
    public void tirarCartas() {

    }


    @Override
    public void mostrarMenuPrincipal() {
        mostrar();
        areaTexto.setText("");
        flujoActual = new FlujoMenuPrincipal(this, controlador);
        flujoActual.mostrarSiguienteTexto();
    }

    public void limpiarPantalla(){
        mostrar();
        areaTexto.setText("");
    }

    public String envido(int pts){
        limpiarPantalla();
        seCantoEnvido=true;
        if(pts > 0) {
            Envido envido1 = new Envido();
            if (envido1.puntajeEnvido(j1) > envido1.puntajeEnvido(j2)) {
                puntosJ1 += pts;
                anotador.sumarJ1(pts);
                return  "Gano " + controlador.nomJug() + " con " + envido1.puntajeEnvido(j1) + " puntos";
            } else if (envido1.puntajeEnvido(j1) < envido1.puntajeEnvido(j2)) {
                puntosJ2 += pts;
                anotador.sumarJ2(pts);
                return "Gano " + j2.getNombre() + " con " + envido1.puntajeEnvido(j2) + " puntos";
            } else {
                if (contadorMano % 2 == 0) {
                    puntosJ1 += pts;
                    anotador.sumarJ1(pts);

                    return "Gano " + controlador.nomJug() + " con " + envido1.puntajeEnvido(j1) + " puntos";
                } else {
                    puntosJ2 += pts;
                    anotador.sumarJ2(pts);
                    return ("Gano " + j2.getNombre() + " con " + envido1.puntajeEnvido(j2) + " puntos");
                }
            }
        }
        else return "";
    }

    public void puntosTruco(Jugador j){ // jugador que gano la mano, falta ese metodo
    }

    public void nuevaMano(){
        anotador.sumarJ1(puntosJ1);
        anotador.sumarJ2(puntosJ2);
        if(finMano) {
            j1.devolverCartas();
            j2.devolverCartas();
            Mazo mazo = new Mazo();
            mazo.repartirCartas(j1, j2);
            limpiarPantalla();
            flujoActual = new FlujoMostrarCartas(this, controlador);
            flujoActual.mostrarSiguienteTexto();
        }
    }

    public boolean getSeCantoEnvido (){
        return seCantoEnvido;
    }

    public void setSeCantoEnvido(boolean op) {
        this.seCantoEnvido = op;
    }

    public String estadoTruco(){
        String result = "null";
        if(!seCantoTruco) result= "truco";
        else if(seCantoTruco) result= "retruco";
        else if(seCantoReTruco) result= "valecuatro";
        else if(seCantoValeCuatro) result= "nada";

        return result;
    }

    public void setEstadoTruco(String estado){
        if(estado.equalsIgnoreCase("truco")) seCantoTruco=true;
        else if(estado.equalsIgnoreCase("retruco")) seCantoReTruco=true;
        else if(estado.equalsIgnoreCase("valecuatro")) seCantoValeCuatro= true;
    }

    public void setFinMano(){
        finMano = true;
    }

    @Override
    public void actualizar() {
    }

    @Override
    public void actualizarCartas() {
        limpiarPantalla();
        flujoActual = new FlujoMostrarCartas(this, controlador);
        flujoActual.mostrarSiguienteTexto();
    }

    @Override
    public void enviarMensaje(String mensaje) {
        println(mensaje);
    }

    public Jugador turno(){
        if(contadorMano % 2 == 0) return j1;
        else return j2;
    }

    @Override
    public void recibirCanto(int mensaje) {
        if(mensaje < 6) {
            seCantoEnvido = true;
            flujoActual = new FlujoEleccionEnvido(this, controlador, mensaje);
            flujoActual.mostrarSiguienteTexto();
        }
        else{
            flujoActual = new FlujoEleccionTruco(this, controlador, mensaje);
            flujoActual.mostrarSiguienteTexto();
        }
    }

    @Override
    public void actualizarPuntos(int j1, int j2) {

    }


}
