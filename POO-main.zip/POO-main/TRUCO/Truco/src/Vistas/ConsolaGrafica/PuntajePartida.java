package Vistas.ConsolaGrafica;

import Controladores.Controlador1;
import Modelos.Anotador;
import Modelos.Jugador;
import Observer.Observer;

import javax.swing.*;

public class PuntajePartida implements Observer {
    private JTextArea txtPuntos;
    private JPanel panel1;
    private Controlador1 controlador;
    private Jugador j1;
    private Jugador j2;
    private final JFrame frame;
    private int puntajeJ1;
    private int puntajeJ2;


    public PuntajePartida(Jugador j1, Jugador j2) {
        this.j1 = j1;
        this.j2 = j2;
        frame = new JFrame("PUNTAJES");
        frame.setContentPane(panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(300, 100);

        puntajeJ2=0;
        puntajeJ1=0;
    }

    public void verPuntajes(){
        frame.setVisible(true);
        txtPuntos.setText("");
        println(j1.getNombre() + ": " + puntajeJ1);
        println(j2.getNombre() + ": " + puntajeJ2);
    }


    public void println(String texto) {
        txtPuntos.append(texto + "\n");
    }

    @Override
    public void actualizar() {

    }

    @Override
    public void actualizarCartas() {

    }

    @Override
    public void enviarMensaje(String mensaje) {

    }

    @Override
    public void recibirCanto(int mensaje) {

    }

    @Override
    public void actualizarPuntos(int j1, int j2) {
        frame.setVisible(true);
        txtPuntos.setText("");
        puntajeJ1 += j1;
        puntajeJ2 += j2;
        println(this.j1.getNombre() + ": " + puntajeJ1);
        println(this.j2.getNombre() + ": " + puntajeJ2);
    }


}
