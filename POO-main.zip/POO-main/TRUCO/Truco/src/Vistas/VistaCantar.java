package Vistas;

public class VistaCantar extends Vista {

    public void cantar(String mensaje){
        mostrarMensaje(mensaje);
    }

}
