package Observer;

import Modelos.Carta;

public interface ObjetoObservable {
    void agregarObservador(Observer observer);
    void quitarObservador(Observer observer);
    void notificarObservadores();
    void notificarCartaTirada(Carta carta);
    void enviarMensaje(String mensaje);
    void notificarCanto(int mensaje);
    void notificarPuntos(int j1, int j2);
}
