package Observer;

import Modelos.Carta;

public interface Observer {
    void actualizar();
    void actualizarCartas();
    void enviarMensaje(String mensaje);
    void recibirCanto(int mensaje);
    void actualizarPuntos(int j1, int j2);
}
