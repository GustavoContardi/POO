package Controladores;

import Modelos.Anotador;
import Modelos.Carta;
import Modelos.Envido;
import Modelos.Jugador;
import Observer.Observer;
import Vistas.ConsolaGrafica.Consola;
import Vistas.IVista;

import java.util.ArrayList;

public class Controlador1 {
    private final Consola vista;
    private Anotador anotador;
    private Jugador modelo;

    public Controlador1(Jugador modelo, Consola vista){
        this.vista = vista;
        this.modelo = modelo;
        vista.setControlador(this);
    }


    public void setAnotador(Anotador anotador) {
        this.anotador = anotador;
        anotador.agregarObservador(vista);
    }

    public void setModelo(Jugador modelo) {
        this.modelo = modelo;
    }

    public void iniciarAlta(String nombre){
        modelo.agregarJugador(new Jugador(nombre));
    }

    public Carta tirarCarta(int numero){
        Carta c = modelo.tirarCarta(numero);
        return c;
    }

    public String nomJug(){
        return modelo.getNombre();
    }

    public ArrayList<Carta> verCartasRepartidas(){
        return modelo.ObtenerCartasRepartidas();

    }

    public void cantar(String canto){
        if(canto.equalsIgnoreCase("truco")) modelo.cantarTruco();
        else if(canto.equalsIgnoreCase("retruco")) modelo.cantarReTruco();
        else if(canto.equalsIgnoreCase("vale cuatro")) modelo.cantarVC();
        else if(canto.equalsIgnoreCase("real envido")) modelo.cantarRealEnvido();
        else if(canto.equalsIgnoreCase("falta envido")) modelo.cantarFaltaEnvido();
        else if(canto.equalsIgnoreCase("envido")) modelo.cantarEnvido();
        else if(canto.equalsIgnoreCase("mazo")) modelo.cantarIrseAlMazo();
    }
    public void enviarMensaje(String mensaje){
        modelo.enviarMensaje(mensaje);
    }
    public void quiero(){
        modelo.cantarQuiero();
    }

    public Jugador getModelo(){
        return modelo;
    }

    public int ptoEnvido(){
        Envido envido = new Envido();
        return envido.puntajeEnvido(modelo);
    }

    public void sumarPuntos(int cantidad, Jugador j){
        if(j.equals(anotador.getJ1())) anotador.sumarJ1(cantidad);
        else if(j.equals(anotador.getJ2()))anotador.sumarJ2(cantidad);
    }

}
