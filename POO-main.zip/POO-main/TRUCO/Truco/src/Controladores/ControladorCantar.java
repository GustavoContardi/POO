package Controladores;

import Modelos.Cantar;
import Modelos.Carta;
import Vistas.VistaCantar;

import java.util.ArrayList;

public class ControladorCantar{
    private VistaCantar vista;
    private Cantar modelo;

    public ControladorCantar(VistaCantar vista, Cantar modelo) {
        this.vista = vista;
        this.modelo = modelo;
    }

    public void cantarAlgo(int opcion){
        switch (opcion){
            case 1 -> vista.cantar(modelo.cantarTruco());
            case 2 -> vista.cantar(modelo.cantarReTruco());
            case 3 -> vista.cantar(modelo.cantarValeCuatro());
            case 4 -> vista.cantar(modelo.cantarEnvido());
            case 5 -> vista.cantar(modelo.cantarRealEnvido());
            case 6 -> vista.cantar(modelo.cantarFaltaEnvido());
            case 7 -> vista.cantar(modelo.cantarFlor());
            case 8 -> vista.cantar(modelo.cantarMeVoyAlMazo());
        }
    }

}
